<?php
	global $portfolio_category, $portfolio_layout, $portfolio_about_project, $portfolio_project_date, $portfolio_project_client, $link;
?>
<article id="cs_post_<?php the_ID(); ?>" <?php post_class('single-small-slider single-post format-gallery row'); ?>>
	    <div class="col-xs-12 col-sm-12 col-md-8 col-lg-8">
	       <?php  
	            get_template_part('framework/templates/portfolio/media');
	        ?>
	    </div>
	    
		<div class="col-sx12 col-sm-12 col-md-4 col-lg-4 cs-scroll-fixed">
			<div class="widget-area">
				<div id="cs-portfolio-content" class="cs-portfolio-content">
					<div class="cs-portfolio-details">
						<?php echo cshero_title_render();?>
					</div>
				</div>
				<div class="cs-portfolio-sidebar">
					<div class="cs-portfolio-share">
					    <div class="social-details">
							<h6 class=""><?php _e('Share', THEMENAME); ?></h6>
							<a
								href="https://www.facebook.com/sharer/sharer.php?u=<?php the_permalink(); ?>"
								target="_blank"><i class="fa fa-facebook"></i></a> <a
								href="https://twitter.com/home?status=<?php the_permalink(); ?>"
								target="_blank"><i class="fa fa-twitter"></i></a> <a
								href="https://plus.google.com/share?url=<?php the_permalink(); ?>"
								target="_blank"><i class="fa fa-google-plus"></i></a> <a
								href="https://www.linkedin.com/shareArticle?mini=true&url=<?php the_permalink(); ?>&title=&summary=&source="
								target="_blank"><i class="fa fa-linkedin"></i></a>
						</div>
					</div>
					<div class="cs-portfolio-text">
						<?php if($portfolio_about_project) {?>
							<?php echo $portfolio_about_project;?>
						<?php } else {?>
							<?php the_content(); ?>
						<?php } ?>
					</div>
					<div class="cs-portfolio-info">
						<div class="cs-portfolio-info-item row">
							<?php if($portfolio_project_date) echo '<div class="col-xs-12 col-sm-6 col-md-6 col-lg-6"><h6>'.__('Date', THEMENAME).'</h6>'.$portfolio_project_date.'</div>';?>
							<div class="col-xs-12 col-sm-6 col-md-6 col-lg-6"><h6><?php _e('Category', THEMENAME); ?></h6><?php the_terms( get_the_ID(), 'portfolio_category', '', ', ', '' ); ?></div>
						</div>
						<?php if($portfolio_project_client) echo '<div class="cs-portfolio-info-item"><h6>'.__('Client', THEMENAME).'</h6>'.$portfolio_project_client.'</div>'; ?>
					</div>
				</div>
			</div>	
		</div>
</article>