(function($) { "use strict";
jQuery(document).ready(function($) {
	$('audio').mediaelementplayer({
		audioWidth: '100%',
        audioHeight: 67
	});
});
})(jQuery);
